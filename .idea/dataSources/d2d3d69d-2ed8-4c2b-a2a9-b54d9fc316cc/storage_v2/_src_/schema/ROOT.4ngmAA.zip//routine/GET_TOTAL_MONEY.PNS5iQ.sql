CREATE FUNCTION get_total_money(
  p_id NUMBER , buy_num NUMBER
)
  RETURN NUMBER
  IS
  v_price NUMBER(10,2);
  v_sum NUMBER(10,2);
  BEGIN
    SELECT pro_price INTO v_price
      FROM PRODUCT
    where pro_id = p_id;
    SELECT v_price* buy_num INTO v_sum FROM dual;
    return v_sum;
  END get_total_money;
/

