CREATE FUNCTION get_product_sumprice
  RETURN NUMBER
  IS 
  v_sum NUMBER(10,2);
  BEGIN
    SELECT sum(p.pro_price * s.sto_number)
    INTO v_sum
    FROM product p , product_stock s
    WHERE p.pro_id = s.pro_id;
    RETURN v_sum;
  END get_product_sumprice;
/

